package example.stepdefs;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import example.pages.TaxCalculatorPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainStepsTaxCalculator {

    private static WebDriver driver = null;

    private TaxCalculatorPage taxCalculatorPage;

    @Before
    public void startUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        taxCalculatorPage = new TaxCalculatorPage(driver);

    }

    @Given("A user is on the Tax Calculator page")
    public void navigateToTaxCalculatorPage() {
        driver.navigate().to("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/your-pay");
    }

    @When("^A user enters an income (.*) and clicks on a rate (.*)")
    public void enterIncomeAndSelectOption(String amount, String option) {
        driver.findElement(By.id("pay-amount")).sendKeys(amount);
        driver.findElement(By.id(option)).click();
    }

    @When("A user selects the option no and clicks continue")
    public void selectOptionAndClickContinue() {
        driver.findElement(By.id("over-state-pension-age-no")).click();
        driver.findElement(By.id("sp-continue")).click();
    }

    @When("The user chooses no tax code and clicks continue")
    public void selectTaxCodeOptionAndClickContinue() {
        driver.findElement(By.id("tax-code-no")).click();
        driver.findElement(By.id("tc-continue")).click();
    }

    @When("The user chooses no scottish income tax and clicks continue")
    public void selectScottishIncomeTaxOptionAndClickContinue() {
        driver.findElement(By.id("scottish-rate-no")).click();
        driver.findElement(By.id("sr-continue")).click();
    }

    @When("The user clicks get results")
    public void selectGetResults () {
        driver.findElement(By.id("get-results")).click();
    }

    @And("A user clicks on the continue button")
    public void clickContinueButton() {
        driver.findElement(By.id("p-continue")).click();
    }

    @Then("^The how many (.*) do you work page is displayed")
    public void verifyTimeYouWorkPageIsDisplayed(String time) {
        Assert.assertEquals(true, driver.findElement(By.id(time)).isDisplayed());
    }

    @Then("The are you over state pension age page is displayed")
    public void verifyStatePensionPageIsDisplayed() {
        Assert.assertEquals(true, driver.findElement(By.id("sp-continue")).isDisplayed());
    }

    @Then("The tax code page is displayed")
    public void verifyTaxCodePageIsDisplayed () {
        Assert.assertEquals(true, driver.findElement(By.id("tc-continue")).isDisplayed());

    }

    @Then("The scottish income tax page is displayed")
    public void verifyScottishTaxPageIsDisplayed () {
        Assert.assertEquals(true, driver.findElement(By.id("sr-continue")).isDisplayed());
    }

    @Then("The check your answers page is displayed")
    public void verifyCheckAnswersPageIsDisplayed () {
        Assert.assertEquals(true, driver.findElement(By.id("get-results")).isDisplayed());
    }

    @Then("The users take home pay is displayed")
    public void verifyTakeHomePayIsDisplayed() {
        Assert.assertEquals(true, driver.findElement(By.id("your-take-home-pay-Year")).isDisplayed());
    }

    @After
    public void tearDown() {
        driver.quit();
    }


}
