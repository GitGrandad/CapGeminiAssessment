package example.pages;

import example.utils.Driver;
import org.openqa.selenium.WebDriver;

public class TaxCalculatorPage extends Driver {

    public TaxCalculatorPage (WebDriver driver) {
        super(driver);
    }

    public TaxCalculatorPage navigateTo() {
        driver.navigate().to("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/your-pay");
        return new TaxCalculatorPage(driver);
    }

}
